Your name: Xirui Ren
Your Pitt username: xir19
Anything that does not work
N/A
Anything else you think might help the grader grade your project more easily
-After one box is at one target, the other boxes will not able to move right or left (by saying unmovable, I means after push right/left, they just disappearn from the board.